export const pokemonListUrl = 'https://api.myjson.com/bins/b0rue';
export const totalPokemon = 649;
