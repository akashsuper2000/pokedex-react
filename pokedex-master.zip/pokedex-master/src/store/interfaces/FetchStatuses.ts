export enum FetchStatuses {
  fetching = 'fetching',
  error = 'error',
  success = 'success'
}
