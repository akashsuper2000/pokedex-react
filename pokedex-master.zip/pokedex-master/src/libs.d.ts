declare module 'react-elm-components';
declare module '*.elm';
